import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from src.config import CATEGORICAL_FEATURES, NUMERIC_FEATURES, TARGET
from src.evaluate import best_threshold
from src.generate_data import make_dataset
from src.models import get_candidates

FEATURES = NUMERIC_FEATURES + CATEGORICAL_FEATURES


def small_data():
    return make_dataset(n=800, seed=1)


def test_dataset_shape_and_target():
    df = small_data()
    assert set(df[TARGET].unique()) == {0, 1}
    assert 0.1 < df[TARGET].mean() < 0.7
    assert df["customer_id"].is_unique


def test_every_model_fits_and_outputs_probabilities():
    df = small_data()
    X_tr, X_te, y_tr, _ = train_test_split(df[FEATURES], df[TARGET], test_size=0.25,
                                           stratify=df[TARGET], random_state=0)
    for name, (pipe, _) in get_candidates().items():
        pipe.fit(X_tr, y_tr)
        p = pipe.predict_proba(X_te)[:, 1]
        assert p.shape[0] == len(X_te), name
        assert np.all((p >= 0) & (p <= 1)), name


def test_pipeline_handles_unseen_category_and_missing_values():
    df = small_data()
    pipe = get_candidates()["Logistic Regression"][0].fit(df[FEATURES], df[TARGET])
    row = df[FEATURES].iloc[[0]].copy()
    row["contract_type"] = "Brand new plan"
    row["total_charges"] = np.nan
    assert pipe.predict_proba(row).shape == (1, 2)


def test_threshold_is_lower_when_missing_churners_is_costly():
    rng = np.random.default_rng(0)
    y = rng.integers(0, 2, 500)
    p = np.clip(y * 0.3 + rng.random(500) * 0.7, 0, 1)
    cheap, _ = best_threshold(y, p, cost_fn=50, cost_fp=50)
    costly, _ = best_threshold(y, p, cost_fn=1000, cost_fp=50)
    assert costly <= cheap
