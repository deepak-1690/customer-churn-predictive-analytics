"""Create a synthetic subscription-customer dataset.

The real project would pull from the billing / CRM database. Until access is
approved, this script produces data with a similar shape so the whole pipeline
can be built and tested. Churn is driven by a logistic relationship with noise,
and a few values are blanked out on purpose to exercise the imputation step.
"""
import numpy as np
import pandas as pd

from src.config import DATA_PATH, RANDOM_STATE


def make_dataset(n: int = 7000, seed: int = RANDOM_STATE) -> pd.DataFrame:
    rng = np.random.default_rng(seed)

    age = rng.integers(18, 80, n)
    contract = rng.choice(["Month-to-month", "One year", "Two year"], n, p=[0.55, 0.25, 0.20])
    internet = rng.choice(["Fiber", "DSL", "None"], n, p=[0.45, 0.35, 0.20])
    payment = rng.choice(
        ["Electronic check", "Credit card", "Bank transfer", "Mailed check"], n,
        p=[0.35, 0.25, 0.25, 0.15],
    )
    paperless = rng.choice(["Yes", "No"], n, p=[0.6, 0.4])
    partner = rng.choice(["Yes", "No"], n, p=[0.48, 0.52])
    senior = np.where(age >= 65, "Yes", "No")

    max_tenure = np.where(contract == "Month-to-month", 40, np.where(contract == "One year", 60, 72))
    tenure = np.minimum(rng.gamma(2.0, 12.0, n).astype(int) + 1, max_tenure)

    base = np.where(internet == "Fiber", 80, np.where(internet == "DSL", 55, 25))
    monthly = np.round(base + rng.normal(0, 8, n), 2).clip(15, 130)
    total = np.round(monthly * tenure * rng.uniform(0.92, 1.05, n), 2)
    calls = rng.poisson(np.where(contract == "Month-to-month", 1.8, 0.8))
    late = rng.poisson(np.where(payment == "Electronic check", 1.2, 0.5))
    gb = np.round(rng.gamma(2.5, 40, n) * np.where(internet == "None", 0.0, 1.0), 1)

    logit = (
        -1.2
        + 1.1 * (contract == "Month-to-month")
        - 0.9 * (contract == "Two year")
        - 0.035 * tenure
        + 0.012 * (monthly - 60)
        + 0.30 * calls
        + 0.25 * late
        + 0.45 * (internet == "Fiber")
        + 0.35 * (payment == "Electronic check")
        + 0.20 * (paperless == "Yes")
        - 0.25 * (partner == "Yes")
        + rng.normal(0, 0.8, n)
    )
    p = 1 / (1 + np.exp(-logit))
    churn = (rng.random(n) < p).astype(int)

    df = pd.DataFrame({
        "customer_id": [f"C{100000 + i}" for i in range(n)],
        "age": age, "tenure_months": tenure, "monthly_charges": monthly,
        "total_charges": total, "support_calls_90d": calls,
        "late_payments_12m": late, "avg_monthly_gb": gb,
        "contract_type": contract, "payment_method": payment,
        "internet_service": internet, "paperless_billing": paperless,
        "senior_citizen": senior, "has_partner": partner, "churn": churn,
    })

    # realistic messiness: ~2% of a few columns missing
    for col in ["total_charges", "avg_monthly_gb", "payment_method"]:
        mask = rng.random(n) < 0.02
        df.loc[mask, col] = np.nan
    return df


if __name__ == "__main__":
    data = make_dataset()
    DATA_PATH.parent.mkdir(parents=True, exist_ok=True)
    data.to_csv(DATA_PATH, index=False)
    print(f"Saved {len(data):,} rows to {DATA_PATH}  |  churn rate = {data['churn'].mean():.1%}")
