"""Candidate models and their tuning grids."""
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.tree import DecisionTreeClassifier

from src.config import RANDOM_STATE
from src.preprocess import build_preprocessor


def get_candidates():
    """Return {name: (pipeline, param_grid)}. Grids are intentionally small
    so the full run finishes in a couple of minutes on a laptop."""
    rs = RANDOM_STATE
    return {
        "Baseline (majority)": (
            Pipeline([("prep", build_preprocessor()), ("clf", DummyClassifier(strategy="prior"))]),
            {},
        ),
        "Logistic Regression": (
            Pipeline([("prep", build_preprocessor()),
                      ("clf", LogisticRegression(max_iter=2000, class_weight="balanced", random_state=rs))]),
            {"clf__C": [0.01, 0.1, 1, 10]},
        ),
        "Decision Tree": (
            Pipeline([("prep", build_preprocessor(scale_numeric=False)),
                      ("clf", DecisionTreeClassifier(class_weight="balanced", random_state=rs))]),
            {"clf__max_depth": [3, 5, 8], "clf__min_samples_leaf": [20, 50]},
        ),
        "Random Forest": (
            Pipeline([("prep", build_preprocessor(scale_numeric=False)),
                      ("clf", RandomForestClassifier(class_weight="balanced_subsample", n_jobs=-1, random_state=rs))]),
            {"clf__n_estimators": [200, 400], "clf__max_depth": [6, 10], "clf__min_samples_leaf": [5, 15]},
        ),
        "Gradient Boosting": (
            Pipeline([("prep", build_preprocessor(scale_numeric=False)),
                      ("clf", HistGradientBoostingClassifier(class_weight="balanced", random_state=rs))]),
            {"clf__learning_rate": [0.03, 0.08], "clf__max_depth": [3, 5], "clf__max_iter": [150, 300]},
        ),
    }
