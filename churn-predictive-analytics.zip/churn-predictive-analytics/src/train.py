"""End-to-end training script.

Steps
 1. load data and hold out a stratified test set (touched only once, at the end)
 2. tune every candidate with GridSearchCV on the training set only
 3. compare tuned models on cross-validated ROC-AUC
 4. choose a cost-based decision threshold using out-of-fold predictions
 5. evaluate the winner on the hold-out set, run a subgroup check, save artefacts

Run from the project root:  python -m src.train
"""
import time

import joblib
import pandas as pd
from sklearn.inspection import permutation_importance
from sklearn.model_selection import GridSearchCV, StratifiedKFold, cross_val_predict, train_test_split

from src import config as C
from src.evaluate import (best_threshold, plot_model_comparison, save_diagnostic_plots,
                          score_all, subgroup_report)
from src.models import get_candidates


def main():
    if not C.DATA_PATH.exists():
        raise SystemExit("Dataset not found. Run `python -m src.generate_data` first.")

    df = pd.read_csv(C.DATA_PATH)
    features = C.NUMERIC_FEATURES + C.CATEGORICAL_FEATURES
    X, y = df[features], df[C.TARGET]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=C.TEST_SIZE, stratify=y, random_state=C.RANDOM_STATE)
    print(f"Train: {len(X_train):,} rows | Test: {len(X_test):,} rows | "
          f"churn rate train {y_train.mean():.1%} / test {y_test.mean():.1%}")

    cv = StratifiedKFold(n_splits=C.CV_FOLDS, shuffle=True, random_state=C.RANDOM_STATE)
    rows, tuned = [], {}

    for name, (pipe, grid) in get_candidates().items():
        t0 = time.time()
        search = GridSearchCV(pipe, grid or {}, scoring="roc_auc", cv=cv, n_jobs=-1, refit=True) \
            if grid else None
        if search is not None:
            search.fit(X_train, y_train)
            best_est, best_idx = search.best_estimator_, search.best_index_
            mean, std = search.cv_results_["mean_test_score"][best_idx], search.cv_results_["std_test_score"][best_idx]
            params = search.best_params_
        else:  # baseline has nothing to tune
            from sklearn.model_selection import cross_val_score
            scores = cross_val_score(pipe, X_train, y_train, scoring="roc_auc", cv=cv)
            best_est = pipe.fit(X_train, y_train)
            mean, std, params = scores.mean(), scores.std(), {}
        tuned[name] = best_est
        rows.append({"model": name, "cv_roc_auc": mean, "cv_roc_auc_std": std,
                     "best_params": params, "seconds": round(time.time() - t0, 1)})
        print(f"  {name:<22} CV ROC-AUC {mean:.3f} +/- {std:.3f}  ({rows[-1]['seconds']}s)")

    results = pd.DataFrame(rows).sort_values("cv_roc_auc", ascending=False).reset_index(drop=True)
    plot_model_comparison(results)

    # Prefer the simpler model if it is within one standard error of the leader.
    complexity = ["Baseline (majority)", "Logistic Regression", "Decision Tree",
                  "Random Forest", "Gradient Boosting"]
    leader = results.iloc[0]
    eligible = results[results["cv_roc_auc"] >= leader["cv_roc_auc"] - leader["cv_roc_auc_std"]]
    winner = min(eligible["model"], key=complexity.index)
    print(f"\nSelected model: {winner}")
    model = tuned[winner]

    # threshold chosen on out-of-fold predictions so the test set stays untouched
    oof = cross_val_predict(model, X_train, y_train, cv=cv, method="predict_proba")[:, 1]
    thr, _ = best_threshold(y_train, oof)
    print(f"Cost-optimal threshold (from training folds): {thr:.2f}")

    proba = model.predict_proba(X_test)[:, 1]
    final = {n: score_all(y_test, tuned[n].predict_proba(X_test)[:, 1], thr if n == winner else 0.5)
             for n in tuned}
    test_table = pd.DataFrame(final).T.round(4)
    test_table.index.name = "model"
    print("\nHold-out test results (winner uses tuned threshold, others 0.50):")
    print(test_table.to_string())

    out = results.merge(test_table.reset_index(), on="model")
    out.to_csv(C.METRICS_PATH, index=False)

    save_diagnostic_plots(winner, y_test, proba, thr)

    print("\nSubgroup check (winner):")
    for col in ["senior_citizen", "contract_type"]:
        print(subgroup_report(X_test[col].reset_index(drop=True), y_test, proba, thr).round(3).to_string(index=False))
        print()

    imp = permutation_importance(model, X_test, y_test, scoring="roc_auc", n_repeats=10,
                                 random_state=C.RANDOM_STATE, n_jobs=-1)
    imp_df = pd.Series(imp.importances_mean, index=features).sort_values(ascending=False)
    print("Top permutation importances (drop in ROC-AUC):")
    print(imp_df.head(8).round(4).to_string())
    imp_df.to_csv(C.ROOT / "reports" / "feature_importance.csv", header=["importance"])

    joblib.dump({"model": model, "threshold": thr, "features": features, "name": winner}, C.MODEL_PATH)
    print(f"\nSaved model to {C.MODEL_PATH}")


if __name__ == "__main__":
    main()
