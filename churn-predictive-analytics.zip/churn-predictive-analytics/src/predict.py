"""Score new customers with the saved model.

Usage:  python -m src.predict path/to/new_customers.csv
"""
import sys

import joblib
import pandas as pd

from src.config import MODEL_PATH


def score(df: pd.DataFrame) -> pd.DataFrame:
    bundle = joblib.load(MODEL_PATH)
    proba = bundle["model"].predict_proba(df[bundle["features"]])[:, 1]
    out = df.copy()
    out["churn_probability"] = proba.round(4)
    out["flagged_for_retention"] = (proba >= bundle["threshold"]).astype(int)
    return out


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python -m src.predict <csv_file>")
    result = score(pd.read_csv(sys.argv[1]))
    print(result.sort_values("churn_probability", ascending=False).head(20).to_string(index=False))
