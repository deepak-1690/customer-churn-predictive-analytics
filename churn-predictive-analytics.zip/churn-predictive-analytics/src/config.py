"""Central settings so every script uses the same paths and seeds."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "customer_churn.csv"
MODEL_PATH = ROOT / "models" / "best_model.joblib"
FIG_DIR = ROOT / "reports" / "figures"
METRICS_PATH = ROOT / "reports" / "metrics.csv"

RANDOM_STATE = 42
TEST_SIZE = 0.20
CV_FOLDS = 5
TARGET = "churn"

NUMERIC_FEATURES = [
    "age", "tenure_months", "monthly_charges", "total_charges",
    "support_calls_90d", "late_payments_12m", "avg_monthly_gb",
]
CATEGORICAL_FEATURES = [
    "contract_type", "payment_method", "internet_service",
    "paperless_billing", "senior_citizen", "has_partner",
]

# Business costs used to pick the decision threshold (currency units per customer).
# FN = a churner we failed to flag (lost margin); FP = retention offer given to someone who would have stayed.
COST_FALSE_NEGATIVE = 150
COST_FALSE_POSITIVE = 50
