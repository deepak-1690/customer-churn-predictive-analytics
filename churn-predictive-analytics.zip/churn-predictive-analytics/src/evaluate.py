"""Metrics, plots and a simple subgroup (fairness) check."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.calibration import calibration_curve
from sklearn.metrics import (
    ConfusionMatrixDisplay, PrecisionRecallDisplay, RocCurveDisplay,
    accuracy_score, average_precision_score, brier_score_loss, f1_score,
    precision_score, recall_score, roc_auc_score,
)

from src.config import COST_FALSE_NEGATIVE, COST_FALSE_POSITIVE, FIG_DIR


def score_all(y_true, proba, threshold=0.5) -> dict:
    pred = (proba >= threshold).astype(int)
    return {
        "accuracy": accuracy_score(y_true, pred),
        "precision": precision_score(y_true, pred, zero_division=0),
        "recall": recall_score(y_true, pred),
        "f1": f1_score(y_true, pred),
        "roc_auc": roc_auc_score(y_true, proba),
        "pr_auc": average_precision_score(y_true, proba),
        "brier": brier_score_loss(y_true, proba),
    }


def best_threshold(y_true, proba, cost_fn=COST_FALSE_NEGATIVE, cost_fp=COST_FALSE_POSITIVE):
    """Pick the cut-off that minimises expected cost.
    Missing a churner (FN) costs more than a wasted retention offer (FP)."""
    y_true = np.asarray(y_true)
    grid = np.linspace(0.05, 0.95, 91)
    costs = []
    for t in grid:
        pred = proba >= t
        fn = np.sum((~pred) & (y_true == 1))
        fp = np.sum(pred & (y_true == 0))
        costs.append(fn * cost_fn + fp * cost_fp)
    i = int(np.argmin(costs))
    return float(grid[i]), float(costs[i])


def save_diagnostic_plots(name, y_true, proba, threshold):
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(1, 3, figsize=(15, 4.2))
    RocCurveDisplay.from_predictions(y_true, proba, ax=ax[0])
    ax[0].set_title("ROC curve")
    PrecisionRecallDisplay.from_predictions(y_true, proba, ax=ax[1])
    ax[1].set_title("Precision-Recall curve")
    ConfusionMatrixDisplay.from_predictions(y_true, (proba >= threshold).astype(int), ax=ax[2], colorbar=False)
    ax[2].set_title(f"Confusion matrix (threshold {threshold:.2f})")
    fig.suptitle(f"{name} - hold-out test set")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "diagnostics.png", dpi=150)
    plt.close(fig)

    frac_pos, mean_pred = calibration_curve(y_true, proba, n_bins=10, strategy="quantile")
    fig, ax = plt.subplots(figsize=(5, 4.5))
    ax.plot([0, 1], [0, 1], "--", color="grey", label="Perfect")
    ax.plot(mean_pred, frac_pos, "o-", label=name)
    ax.set_xlabel("Mean predicted probability")
    ax.set_ylabel("Observed churn rate")
    ax.set_title("Calibration curve")
    ax.legend()
    fig.tight_layout()
    fig.savefig(FIG_DIR / "calibration.png", dpi=150)
    plt.close(fig)


def plot_model_comparison(results: pd.DataFrame):
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    r = results.sort_values("cv_roc_auc")
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.barh(r["model"], r["cv_roc_auc"], xerr=r["cv_roc_auc_std"], color="#3b6ea8")
    ax.set_xlim(0.4, max(0.9, r["cv_roc_auc"].max() + 0.05))
    ax.set_xlabel("Cross-validated ROC-AUC (mean +/- std)")
    ax.set_title("Model comparison")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "model_comparison.png", dpi=150)
    plt.close(fig)


def subgroup_report(groups: pd.Series, y_true, proba, threshold) -> pd.DataFrame:
    """Recall / precision / flag-rate per subgroup, to spot uneven performance."""
    y_true = np.asarray(y_true)
    pred = (np.asarray(proba) >= threshold).astype(int)
    g = np.asarray(groups)
    rows = []
    for val in sorted(set(g)):
        m = g == val
        rows.append({
            "group": val, "n": int(m.sum()),
            "actual_churn_rate": y_true[m].mean(),
            "flagged_rate": pred[m].mean(),
            "recall": recall_score(y_true[m], pred[m], zero_division=0),
            "precision": precision_score(y_true[m], pred[m], zero_division=0),
        })
    return pd.DataFrame(rows)
